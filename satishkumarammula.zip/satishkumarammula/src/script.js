document.addEventListener("DOMContentLoaded", () => {
  const skills = document.querySelector(".skills ul");
  const hackerEffect = setInterval(() => {
    skills.classList.toggle("hacker-animation");
  }, 1000);

  // Optional: Add a random text flicker effect
  document.body.addEventListener("mousemove", () => {
    document.body.style.backgroundColor = `#${Math.floor(
      Math.random() * 16777215
    ).toString(16)}`;
  });
});
